import axios from 'axios';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8030';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export interface IngestResponse {
  file: string;
  chunks: number;
}

export interface QueryResponse {
  query: string;
  response: string;
  sources: Array<{
    text: string;
    score: number;
  }>;
}

export const ingestDocument = async (file: File): Promise<IngestResponse> => {
  const formData = new FormData();
  formData.append('file', file);

  const { data } = await apiClient.post<IngestResponse>('/ingest', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });

  return data;
};

export const queryDocuments = async (
  query: string,
  topK: number = 3
): Promise<QueryResponse> => {
  const { data } = await apiClient.post<QueryResponse>('/query', {
    query,
    top_k: topK,
  });

  return data;
};
